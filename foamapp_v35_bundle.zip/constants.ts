
// Web App URL from Google Apps Script Deployment (Main Backend)
export const GOOGLE_SCRIPT_URL: string ='https://script.google.com/macros/s/AKfycbwBCXzd2SL9l27tkYHGQLisOHeizaxH6aXNyfH0E1I2oWI1vtNOQ0URNsWEyi1ZjF5BDg/exec'

// Web App URL for the Dedicated Email Service (Separate Script)
// TODO: Deploy backend/EmailService.js and paste the Web App URL here
export const EMAIL_SERVICE_URL: string = 'https://script.google.com/macros/s/AKfycbx7UdOPtl1kbNZIiAX-72oc_GBOplQGkjpM5UqHsJdiJCcORzCgfjfpVTMsNL_EjxE/exec';
